package unoeste.fipp.playmbs.restcontrollers;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import unoeste.fipp.playmbs.entites.Erro;
import unoeste.fipp.playmbs.entites.Music;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/apis") // Mantendo a URL base para organização
@CrossOrigin(origins = "*") // Permite requisições de qualquer origem (CORS)
public class MusicRestController {

    @Autowired
    private HttpServletRequest request;
    private final String UPLOAD_FOLDER = System.getProperty("user.dir") + "/uploads/";
    //private final String UPLOAD_FOLDER = "src/main/resources/static/uploads/";

    @PostMapping("/add-music")
    public ResponseEntity<Object> addMusic(
            @RequestParam("file") MultipartFile file,
            @RequestParam("titulo") String titulo,
            @RequestParam("artista") String artista,
            @RequestParam("estilo") String estilo) {
        try {
            File uploadFolder = new File(UPLOAD_FOLDER);
            if (!uploadFolder.exists()) uploadFolder.mkdirs(); // Cria a pasta, se não existir

            String fileName = titulo.replace(" ", "_") + "_" + estilo.replace(" ", "_") + "_" + artista.replace(" ", "_") + ".mp3";
            File destFile = new File(uploadFolder, fileName);
            file.transferTo(destFile);

            Music music = new Music(titulo, artista, estilo, fileName);
            return ResponseEntity.ok(music);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new Erro("Erro ao armazenar o arquivo: " + e.getMessage()));
        }
    }

    @GetMapping("/find-musics")
    public ResponseEntity<Object> findMusics(@RequestParam(required = false) String busca) {
        File uploadFolder = new File(UPLOAD_FOLDER);
        String[] files = uploadFolder.list();
        List<Music> musicList = new ArrayList<>();

        if (files != null) {
            for (String f : files) {
                if (f.toLowerCase().endsWith(".mp3")) {
                    String[] parts = f.replace(".mp3", "").split("_", 3);

                    String titulo = (parts.length > 0) ? parts[0].replace("_", " ") : "Título Desconhecido";
                    String artista = (parts.length > 2) ? parts[2].replace("_", " ") : "Artista Desconhecido";
                    String estilo = (parts.length > 1) ? parts[1].replace("_", " ") : "Estilo Desconhecido";

                    // 🔹 Usando getHostStatic() para gerar o caminho correto
                    String fileUrl = getHostStatic() + "/" + f;

                    Music music = new Music(titulo, artista, estilo, fileUrl);

                    if (busca == null ||
                            titulo.toLowerCase().contains(busca.toLowerCase()) ||
                            artista.toLowerCase().contains(busca.toLowerCase()) ||
                            estilo.toLowerCase().contains(busca.toLowerCase())) {
                        musicList.add(music);
                    }
                }
            }
        }

        if (musicList.isEmpty()) {
            return ResponseEntity.ok(new Erro("Nenhuma música encontrada."));
        }

        return ResponseEntity.ok(musicList);
    }



    private String getHostStatic() {
        return "http://" + request.getServerName() + ":" + request.getServerPort() + "/uploads";
    }

}
