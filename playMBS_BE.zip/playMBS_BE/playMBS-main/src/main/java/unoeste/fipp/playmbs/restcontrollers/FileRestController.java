package unoeste.fipp.playmbs.restcontrollers;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;

@RestController
@RequestMapping("/uploads")
@CrossOrigin(origins = "*")
public class FileRestController {

    private final String UPLOAD_FOLDER = System.getProperty("user.dir") + "/uploads/";

    @GetMapping("/{filename:.+}")
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
        File file = new File(UPLOAD_FOLDER + filename);

        if (!file.exists()) {
            return ResponseEntity.notFound().build();
        }

        Resource resource = new FileSystemResource(file);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, "audio/mpeg"); // Define o tipo de conteúdo

        return ResponseEntity.ok().headers(headers).body(resource);
    }
}
